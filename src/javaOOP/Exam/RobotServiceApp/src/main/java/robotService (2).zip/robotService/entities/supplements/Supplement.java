package robotService.entities.supplements;

public interface Supplement {
    int getHardness();
    double getPrice();
}
