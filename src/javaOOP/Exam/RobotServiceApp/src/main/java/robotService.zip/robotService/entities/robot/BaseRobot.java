package robotService.entities.robot;

public abstract class BaseRobot implements Robot{

    private String name;
    private String kind;
    private int kilograms;
    private double price;

    public BaseRobot(String name, String kind, int kilograms, double price) {
        this.name = name;
        this.kind = kind;
        this.kilograms = kilograms;
        this.price = price;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public void setName(String name) {

    }

    @Override
    public int getKilograms() {
        return 0;
    }

    @Override
    public double getPrice() {
        return 0;
    }

    @Override
    public abstract void eating() ;
}
