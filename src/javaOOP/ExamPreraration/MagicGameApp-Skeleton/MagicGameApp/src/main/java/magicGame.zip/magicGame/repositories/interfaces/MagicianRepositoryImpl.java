package magicGame.repositories.interfaces;

import magicGame.models.magicians.Magician;

import java.util.Collection;

public class MagicianRepositoryImpl implements MagicianRepository {
    Collection<Magician> data;

    public MagicianRepositoryImpl(Collection<Magician> data) {
        this.data = data;
    }

    @Override
    public Collection getData() {
        return this.data;
    }

    @Override
    public void addMagician(Magician model) {
        if (model == null) {
            throw new NullPointerException("Cannot add null in Magician Repository.");
        }
        data.add(model);
    }

    @Override
    public boolean removeMagician(Magician model) {
        if (data.contains(model)) {
            data.remove(model);
            return true;
        }
        return false;
    }

    @Override
    public Object findByUsername(String name) {
        for (Magician magician : data) {
            if (magician.getUsername().equals(name)) {
                return magician;
            }
        }
        return null;
    }
}
