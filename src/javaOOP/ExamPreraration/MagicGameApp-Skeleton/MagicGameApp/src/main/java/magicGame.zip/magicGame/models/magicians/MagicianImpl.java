package magicGame.models.magicians;

import magicGame.models.magics.Magic;

public abstract class MagicianImpl implements Magician {


    private String username;

    private int health;

    private int protection;

    private boolean isAlive;

    private Magic magic;

    protected MagicianImpl(String username, int health, int protection, Magic magic) {
        setUsername(username);
        setHealth(health);
        setProtection(protection);
        setMagic(magic);
        setAlive(true);
    }

    private void setUsername(String username) {
        if (username.trim().isEmpty() || username == null) {
            throw new NullPointerException("Username cannot be null or empty.");
        }
        this.username = username;
    }

    private void setHealth(int health) {
        if (health < 0) {
            throw new IllegalArgumentException("Magician health cannot be below 0.");
        }
        this.health = health;
    }

    private void setProtection(int protection) {
        if (protection < 0) {
            throw new IllegalArgumentException("Magician protection cannot be below 0.");
        }
        this.protection = protection;
    }

    private void setAlive(boolean alive) {
        isAlive = alive;
    }

    private void setMagic(Magic magic) {
        if (magic == null) {
            throw new NullPointerException("Magic cannot be null.");
        }
        this.magic = magic;
    }
    @Override
    public void takeDamage(int points) {
        if (!this.isAlive) {
            return;
        }
        this.protection -= points;
        if (this.protection < 0) {
            this.health += this.protection;
        }
        if (this.health <= 0) {
            setAlive(false);
        }

    }
    @Override
    public String getUsername() {
        return username;
    }
    @Override
    public int getProtection() {
        return protection;
    }
    @Override
    public boolean isAlive() {
        return isAlive;
    }
    @Override
    public Magic getMagic() {
        return magic;
    }
    @Override
    public int getHealth() {
        return health;
    }
}
