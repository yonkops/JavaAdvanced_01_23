package vehicles;

public abstract class Vehicle {
    private double fuelQuantity;
    private double fuelPerKm;

    public Vehicle(double fuelQuantity, double fuelPerKm) {
        this.fuelQuantity = fuelQuantity;
        this.fuelPerKm = fuelPerKm;
    }
    protected boolean drive(double distance){
        double neededFuel = distance * fuelPerKm;
        if (fuelQuantity >= neededFuel){
            fuelQuantity -= neededFuel;
            return true;
        }
        return false;
    }
    protected abstract void refuel(double fuel);

    protected double getFuelQuantity() {
        return fuelQuantity;
    }

    protected void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }
}
