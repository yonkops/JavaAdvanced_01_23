package vehicles;

public class Truck extends Vehicle {
    private static final double CONSUMPTION_INCREASE = 1.6;
    private static final double FUEL_LOSSES = 0.95;

    public Truck(double fuelQuantity, double fuelPerKm) {
        super(fuelQuantity, fuelPerKm + CONSUMPTION_INCREASE);
    }
    @Override
    protected void refuel(double fuel) {
        setFuelQuantity((getFuelQuantity() + (fuel * FUEL_LOSSES)));
    }
}
