package vehicles;

import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        Scanner scanner = new Scanner(System.in);
        Map<String, Vehicle> data = new LinkedHashMap<>();
        makeCar(scanner, data);
        makeTruck(scanner, data);
        int commandsNumber = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < commandsNumber; i++) {
            String[] input = scanner.nextLine().split("\\s+");
            String command = input[0];
            String vehicle = input[1];
            double parsedDouble = Double.parseDouble(input[2]);

            switch (command){
                case "Drive" :
                    if (data.get(vehicle).drive(parsedDouble)){
                        System.out.printf("%s travelled %s km%n",
                                vehicle, (decimalFormat.format(parsedDouble)));
                    } else {
                        System.out.printf("%s needs refueling%n",
                                input[1]);
                    }
                    break;
                case "Refuel" :
                    data.get(input[1]).refuel(Double.parseDouble(input[2]));
                    break;
            }
        }
        for (String vehicle : data.keySet()) {
            System.out.println(String.format("%s: %.2f",
                    vehicle, data.get(vehicle).getFuelQuantity()));
        }


    }

    private static void makeTruck(Scanner scanner, Map<String, Vehicle> data) {
        String[] input;
        double fuelPerKm;
        double fuelQuantity;
        input = scanner.nextLine().split("\\s+");
        fuelQuantity = Double.parseDouble(input[1]);
        fuelPerKm = Double.parseDouble(input[2]);
        Truck truck = new Truck(fuelQuantity, fuelPerKm);
        data.put(input[0], truck);
    }

    private static void makeCar(Scanner scanner, Map<String, Vehicle> data) {
        String [] input = scanner.nextLine().split("\\s+");
        double fuelQuantity = Double.parseDouble(input[1]);
        double fuelPerKm = Double.parseDouble(input[2]);
        Car car = new Car(fuelQuantity, fuelPerKm);
        data.put(input[0], car);
    }
}
