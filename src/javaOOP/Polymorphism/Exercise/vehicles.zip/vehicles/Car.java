package vehicles;

public class Car extends Vehicle {
    private static final double CONSUMPTION_INCREASE = 0.9;
    public Car(double fuelQuantity, double fuelPerKm) {
        super(fuelQuantity, fuelPerKm + CONSUMPTION_INCREASE);
    }

    @Override
    protected void refuel(double fuel) {
        setFuelQuantity(getFuelQuantity() + fuel);
    }
}
